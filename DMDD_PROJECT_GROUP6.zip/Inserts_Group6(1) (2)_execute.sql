Use Airline_Reservation_System_temp
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (1234, N'Shashank', N'Mumbai')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (1534, N'Aarti', N'Delhi')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (2087, N'Olivia', N'Urban hill')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (2578, N'Piyush', N'Kolkata')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (2934, N'Ethan', N'texas')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (2985, N'Shweta', N'Mumbai')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (3945, N'Narendar', N'Tamil Nadu')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (5839, N'Priyanka', N'Connecticut')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (7529, N'Eshaan', N'Virginia')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (8713, N'Sam', N'Boston')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (8792, N'Asim', N'Washington DC')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (9863, N'Aakoo', N'California')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (9874, N'Priyank', N'Bangalore')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (9876, N'Milind', N'Chennai')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (28756, N'Jitin', N'Connecticut')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (34670, N'Herika', N'New York')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (68390, N'Niyati', N'New York')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (83875, N'Apoorva', N'Bangalore')
GO
INSERT [dbo].[Agent_T] ([Agent_ID], [AgentName], [AgentDetails]) VALUES (98274, N'Gauri', N'Mumbai')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (1093, N'Alexa', N'Dheeren', N'F', CAST(N'2021-01-10' AS Date), N'Alexa@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Syracuse')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (1567, N'Mohitesh', N'Mehta', N'M', CAST(N'2000-02-02' AS Date), N'Mohitesh@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Mission Hill')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (2087, N'Adam', N'Joshi', N'M', CAST(N'1985-12-27' AS Date), N'Adam@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Boston')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (2478, N'Akshay', N'Shiwale', N'M', CAST(N'2005-10-09' AS Date), N'Akshay@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Texas')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (2984, N'Aarti', N'Mehta', N'F', CAST(N'1995-11-19' AS Date), N'mehta@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'75 alphonsus street')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (2985, N'Otis', N'Koshti', N'M', CAST(N'1984-05-08' AS Date), N'Otis@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'ohio')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (3399, N'Iqra', N'Murugesan', N'F', CAST(N'1959-05-30' AS Date), N'Iqra@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Georgia')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (3857, N'Shweta', N'Bongale', N'F', CAST(N'1973-12-01' AS Date), N'shweta@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Mission Main')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (3984, N'Erin', N'Christopher', N'M', CAST(N'2010-07-12' AS Date), N'Erin@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'California')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (4042, N'Anjna', N'Suresh', N'F', CAST(N'2010-07-01' AS Date), N'Anjna@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Florida')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (4084, N'Cutie', N'Tripathi', N'F', CAST(N'1977-08-07' AS Date), N'Cutie@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Alaska')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (4865, N'Heri', N'Pasarkar', N'F', CAST(N'1990-03-11' AS Date), N'Heri@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'New Jersey')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (4922, N'Jose', N'Indi', N'M', CAST(N'1964-09-01' AS Date), N'Jose@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Montana')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (4975, N'Pooja', N'Narayankar', N'F', CAST(N'2007-10-31' AS Date), N'Pooja@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Michigan')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (4986, N'Aleem', N'Nicole', N'M', CAST(N'1996-12-31' AS Date), N'Aleem@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Indiana')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (5098, N'Ola', N'Chauhan', N'F', CAST(N'1992-07-30' AS Date), N'Ola@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Virginia')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (5804, N'Aditya', N'Bhosle', N'M', CAST(N'2021-11-02' AS Date), N'Aditya@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'San fransico')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (5839, N'Carson', N'Bhawankar', N'M', CAST(N'1993-10-15' AS Date), N'Carson@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Maine')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (5897, N'Macrin', N'Vasu', N'M', CAST(N'2013-06-30' AS Date), N'Macrin@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Connecticut')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (5920, N'Chiege', N'Chopra', N'M', CAST(N'1996-10-16' AS Date), N'Chiege@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Nevada')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (5973, N'Joe', N'Salunke', N'M', CAST(N'1973-06-14' AS Date), N'Joe@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Pennisylvia')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (6502, N'Aslam', N'Maheshwari', N'M', CAST(N'1978-06-10' AS Date), N'Aslam@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Oregon')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (6802, N'Gaurav', N'Ghorpade', N'M', CAST(N'2020-01-20' AS Date), N'Gaurav@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Ohio')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (6972, N'Poo', N'Patil', N'F', CAST(N'1999-01-01' AS Date), N'Poo@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Pittsburg')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (7722, N'Prathamesh', N'Kakkar', N'M', CAST(N'1969-06-09' AS Date), N'Prathamesh@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Hawaii')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (1566, N'Alexa', N'Dheeren', N'F', CAST(N'2021-01-10' AS Date), N'milind.trivedi61@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Syracuse')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (8654, N'Alex', N'Dandekar', N'M', CAST(N'1973-02-28' AS Date), N'Alex@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'New york')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (8753, N'Tang', N'Dubey', N'M', CAST(N'1998-11-17' AS Date), N'Tang@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Utah')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (8755, N'Atif', N'Shwale', N'M', CAST(N'1990-07-06' AS Date), N'Atif@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Minnesota')
GO
INSERT [dbo].[Customer_T] ([Customer_ID], [FirstName], [LastName], [Gender], [DOB], [email], [Password], [address]) VALUES (9933, N'Emily', N'Balch', N'F', CAST(N'1991-09-15' AS Date), N'Emily@gmail.com', N' 6ÉMAÖI²Z¾=H]G   O’>k¿CÐ˜4úP¬.ƒ%ÂGü†2Ã?‘5–Ð', N'Maryland')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510000', 2985, 1234, N'WTLST', CAST(N'2021-12-22' AS Date), N'FC')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510010', 8654, 2578, N'APPRVD', CAST(N'2020-10-16' AS Date), N'BSC')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510013', 2087, 9876, N'APPRVD', CAST(N'2021-06-10' AS Date), N'EC')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510021', 6972, 1234, N'APPRVD', CAST(N'2022-05-29' AS Date), N'PEC')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510038', 1566, 83875, N'APPRVD', CAST(N'2022-04-28' AS Date), N'BSC')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510027', 1567, 28756, N'RJCTD', CAST(N'2019-12-03' AS Date), N'BEC')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510031', 1093, 83875, N'APPRVD', CAST(N'2021-08-08' AS Date), N'FC')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510036', 6802, 83875, N'APPRVD', CAST(N'2022-04-28' AS Date), N'BSC')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510047', 3984, 28756, N'APPRVD', CAST(N'2022-03-15' AS Date), N'BSC')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510052', 4865, 1234, N'RJCTD', CAST(N'2020-12-19' AS Date), N'EC')
GO
INSERT [dbo].[RESERVATION_T] ([Reservation_id], [Customer_id], [Agent_id], [Reservation_status_code], [Reservation_date], [Travel_class_code]) VALUES (N'RS11510065', 2984, 9876, N'APPRVD', CAST(N'2021-06-18' AS Date), N'BSC')
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (1357, N'QAT7648', N'bos', N'kol', CAST(N'2022-01-13T12:45:00.000' AS DateTime), CAST(N'2022-01-14T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (2097, N'QAT1524', N'CAL', N'DOM', CAST(N'2021-12-12T10:45:00.000' AS DateTime), CAST(N'2021-12-13T02:25:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (2345, N'QAT1297', N'DEL', N'DOM', CAST(N'2021-12-23T10:45:00.000' AS DateTime), CAST(N'2021-12-23T02:28:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (2465, N'AMR2345', N'DEL', N'NYC', CAST(N'2022-01-15T12:45:00.000' AS DateTime), CAST(N'2022-01-16T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (2466, N'AIR3786', N'DEL', N'bom', CAST(N'2021-12-23T12:45:00.000' AS DateTime), CAST(N'2021-12-24T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (2545, N'AMR3536', N'DEL', N'DOM', CAST(N'2021-12-23T07:45:00.000' AS DateTime), CAST(N'2021-12-23T02:28:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (2546, N'Indi1550', N'bos', N'bom', CAST(N'2022-01-11T12:45:00.000' AS DateTime), CAST(N'2022-01-12T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (2547, N'Indi1550', N'DEL', N'bom', CAST(N'2022-01-22T12:45:00.000' AS DateTime), CAST(N'2022-01-23T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (2565, N'AMR2345', N'DEL', N'DOM', CAST(N'2021-12-23T07:45:00.000' AS DateTime), CAST(N'2021-12-23T02:28:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (2567, N'Indi1550', N'kol', N'bom', CAST(N'2021-12-26T12:45:00.000' AS DateTime), CAST(N'2021-12-27T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (2577, N'Indi1550', N'CAL', N'kol', CAST(N'2022-01-24T12:45:00.000' AS DateTime), CAST(N'2022-01-25T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (3257, N'QAT7648', N'DEL', N'kol', CAST(N'2022-01-30T12:45:00.000' AS DateTime), CAST(N'2022-01-31T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (3567, N'QAT7648', N'DEL', N'bom', CAST(N'2022-01-11T12:45:00.000' AS DateTime), CAST(N'2022-01-12T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (3577, N'AMR2345', N'NYC', N'bom', CAST(N'2022-01-25T12:45:00.000' AS DateTime), CAST(N'2022-01-26T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (3578, N'AMR2345', N'NYC', N'bom', CAST(N'2022-01-29T12:45:00.000' AS DateTime), CAST(N'2022-01-30T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (3745, N'Indi1524', N'bos', N'bom', CAST(N'2021-12-19T11:45:00.000' AS DateTime), CAST(N'2021-12-20T01:25:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (3748, N'AIR1524', N'NYK', N'bom', CAST(N'2021-12-12T10:45:00.000' AS DateTime), CAST(N'2021-12-13T02:25:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (5463, N'QAT7648', N'bos', N'bom', CAST(N'2021-12-21T12:45:00.000' AS DateTime), CAST(N'2021-12-22T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (5733, N'AIR3786', N'bos', N'CAL', CAST(N'2022-01-29T12:45:00.000' AS DateTime), CAST(N'2022-01-30T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (5785, N'QAT7648', N'kol', N'bom', CAST(N'2022-01-28T12:45:00.000' AS DateTime), CAST(N'2022-01-29T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (7432, N'Indi1550', N'CAL', N'kol', CAST(N'2022-01-14T12:45:00.000' AS DateTime), CAST(N'2022-01-15T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (7883, N'QAT7648', N'bos', N'kol', CAST(N'2022-01-30T12:45:00.000' AS DateTime), CAST(N'2022-01-31T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (8352, N'QAT7648', N'bos', N'kol', CAST(N'2021-12-25T12:45:00.000' AS DateTime), CAST(N'2021-12-26T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (8467, N'AMR2345', N'NYC', N'kol', CAST(N'2021-12-24T12:45:00.000' AS DateTime), CAST(N'2021-12-25T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (8642, N'AIR3786', N'CAL', N'NYC', CAST(N'2022-01-30T12:45:00.000' AS DateTime), CAST(N'2022-01-31T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FlightSchedule_T] ([Flight_No], [Airplane_ID], [Origin_Airport_Code], [Destination_Airport_Code], [Arrival_Time], [Departure_Time]) VALUES (8888, N'Indi1550', N'bos', N'DEL', CAST(N'2022-01-27T12:45:00.000' AS DateTime), CAST(N'2022-01-28T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[ITINERARY_LEGS_T] ([Reservation_id], [Flight_No]) VALUES (N'RS11510065', 5463)
GO
INSERT [dbo].[ITINERARY_LEGS_T] ([Reservation_id], [Flight_No]) VALUES (N'RS11510052', 8467)
GO
INSERT [dbo].[ITINERARY_LEGS_T] ([Reservation_id], [Flight_No]) VALUES (N'RS11510000', 3567)
GO
INSERT [dbo].[ITINERARY_LEGS_T] ([Reservation_id], [Flight_No]) VALUES (N'RS11510013', 3577)
GO
INSERT [dbo].[ITINERARY_LEGS_T] ([Reservation_id], [Flight_No]) VALUES (N'RS11510021', 2577)
GO
INSERT [dbo].[ITINERARY_LEGS_T] ([Reservation_id], [Flight_No]) VALUES (N'RS11510047', 2547)
GO
INSERT [dbo].[ITINERARY_LEGS_T] ([Reservation_id], [Flight_No]) VALUES (N'RS11510031', 7883)
GO
INSERT [dbo].[ITINERARY_LEGS_T] ([Reservation_id], [Flight_No]) VALUES (N'RS11510036', 5733)
GO
INSERT [dbo].[ITINERARY_LEGS_T] ([Reservation_id], [Flight_No]) VALUES (N'RS11510065', 5785)
GO
INSERT [dbo].[ITINERARY_LEGS_T] ([Reservation_id], [Flight_No]) VALUES (N'RS11510052', 3578)
GO
INSERT [dbo].[Transactions_T] ([TransactionID], [TransactionStatus], [TransactionAmount], [TransactionDate]) VALUES (N'MBK1112345', N'Failed', CAST(77876.88 AS Decimal(10, 2)), CAST(N'2021-03-30' AS Date))
GO
INSERT [dbo].[Transactions_T] ([TransactionID], [TransactionStatus], [TransactionAmount], [TransactionDate]) VALUES (N'MBK1271122', N'Success', CAST(24545.00 AS Decimal(10, 2)), CAST(N'2021-09-20' AS Date))
GO
INSERT [dbo].[Transactions_T] ([TransactionID], [TransactionStatus], [TransactionAmount], [TransactionDate]) VALUES (N'MBK1274346', N'Success', CAST(23457.44 AS Decimal(10, 2)), CAST(N'2021-06-15' AS Date))
GO
INSERT [dbo].[Transactions_T] ([TransactionID], [TransactionStatus], [TransactionAmount], [TransactionDate]) VALUES (N'MBK1276154', N'Success', CAST(23456.40 AS Decimal(10, 2)), CAST(N'2021-07-23' AS Date))
GO
INSERT [dbo].[Transactions_T] ([TransactionID], [TransactionStatus], [TransactionAmount], [TransactionDate]) VALUES (N'MBK1276544', N'Success', CAST(33256.40 AS Decimal(10, 2)), CAST(N'2021-09-15' AS Date))
GO
INSERT [dbo].[Transactions_T] ([TransactionID], [TransactionStatus], [TransactionAmount], [TransactionDate]) VALUES (N'MBK1276721', N'Success', CAST(33456.40 AS Decimal(10, 2)), CAST(N'2021-07-15' AS Date))
GO
INSERT [dbo].[Transactions_T] ([TransactionID], [TransactionStatus], [TransactionAmount], [TransactionDate]) VALUES (N'MBK1276722', N'Failed', CAST(33448.00 AS Decimal(10, 2)), CAST(N'2021-07-17' AS Date))
GO
INSERT [dbo].[Transactions_T] ([TransactionID], [TransactionStatus], [TransactionAmount], [TransactionDate]) VALUES (N'MBK1276766', N'Success', CAST(33456.40 AS Decimal(10, 2)), CAST(N'2021-07-15' AS Date))
GO
INSERT [dbo].[Transactions_T] ([TransactionID], [TransactionStatus], [TransactionAmount], [TransactionDate]) VALUES (N'MBK1338788', N'Success', CAST(45665.00 AS Decimal(10, 2)), CAST(N'2021-10-19' AS Date))
GO
INSERT [dbo].[Transactions_T] ([TransactionID], [TransactionStatus], [TransactionAmount], [TransactionDate]) VALUES (N'MBK1767733', N'Success', CAST(88765.34 AS Decimal(10, 2)), CAST(N'2021-09-11' AS Date))
GO
INSERT [dbo].[ReservationPayment_T] ([ReservationID], [PaymentID]) VALUES (N'RS11510000', N'MBK1276766')
GO
INSERT [dbo].[ReservationPayment_T] ([ReservationID], [PaymentID]) VALUES (N'RS11510010', N'MBK1276722')
GO
INSERT [dbo].[ReservationPayment_T] ([ReservationID], [PaymentID]) VALUES (N'RS11510013', N'MBK1274346')
GO
INSERT [dbo].[ReservationPayment_T] ([ReservationID], [PaymentID]) VALUES (N'RS11510021', N'MBK1276544')
GO
INSERT [dbo].[ReservationPayment_T] ([ReservationID], [PaymentID]) VALUES (N'RS11510027', N'MBK1276721')
GO
INSERT [dbo].[ReservationPayment_T] ([ReservationID], [PaymentID]) VALUES (N'RS11510047', N'MBK1276154')
GO
INSERT [dbo].[ReservationPayment_T] ([ReservationID], [PaymentID]) VALUES (N'RS11510031', N'MBK1271122')
GO
INSERT [dbo].[ReservationPayment_T] ([ReservationID], [PaymentID]) VALUES (N'RS11510036', N'MBK1112345')
GO
INSERT [dbo].[ReservationPayment_T] ([ReservationID], [PaymentID]) VALUES (N'RS11510065', N'MBK1338788')
GO
INSERT [dbo].[ReservationPayment_T] ([ReservationID], [PaymentID]) VALUES (N'RS11510052', N'MBK1767733')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD180 ', N' United ', N' Airbus ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD181 ', N' Jetblue ', N' Leonardo ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD182 ', N' Delta ', N' Boeing ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD183 ', N' Air France ', N' Embraer ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD184 ', N' American ', N' Bombardier ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD185 ', N' United ', N' Airbus ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD186 ', N' Jetblue ', N' Leonardo ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD187 ', N' Delta ', N' Boeing ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD188 ', N' Air France ', N' Embraer ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD189 ', N' American ', N' Bombardier ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD190 ', N' United ', N' Airbus ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N' MD191 ', N' Jetblue ', N' Leonardo ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD180', N'United', N'Airbus')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD181', N'Jetblue', N'Leonardo')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD182', N'Delta', N'Boeing ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD183', N'Air France', N'Embraer')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD184 ', N'American', N'Bombardier')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD185', N'United', N'Airbus ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD186', N'Jetblue', N'Leonardo')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD187', N'Delta', N'Boeing ')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD188', N'Air France', N'Embraer')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD189', N'American', N'Bombardier')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD190', N'United', N'Airbus')
GO
INSERT [dbo].[AIRLINE_t] ([Airline_id], [Name], [Manufacturer]) VALUES (N'MD191', N'Jetblue', N'Leonardo')
GO
INSERT [dbo].[AIRPLANE_T] ([Airplane_id], [Airline_id], [Number_of_Seats], [ModelNumber]) VALUES (N'AIR1524', N'MD184', 430, N'747')
GO
INSERT [dbo].[AIRPLANE_T] ([Airplane_id], [Airline_id], [Number_of_Seats], [ModelNumber]) VALUES (N'AIR2850', N' MD190', 115, N' 747')
GO
INSERT [dbo].[AIRPLANE_T] ([Airplane_id], [Airline_id], [Number_of_Seats], [ModelNumber]) VALUES (N'AIR3786', N' MD184', 545, N' A319')
GO
INSERT [dbo].[AIRPLANE_T] ([Airplane_id], [Airline_id], [Number_of_Seats], [ModelNumber]) VALUES (N'AMR2345', N'MD185', 688, N'707')
GO
INSERT [dbo].[AIRPLANE_T] ([Airplane_id], [Airline_id], [Number_of_Seats], [ModelNumber]) VALUES (N'AMR3536', N'MD191', 350, N'747')
GO
INSERT [dbo].[AIRPLANE_T] ([Airplane_id], [Airline_id], [Number_of_Seats], [ModelNumber]) VALUES (N'Indi1524', N'MD183', 760, N'A319')
GO
INSERT [dbo].[AIRPLANE_T] ([Airplane_id], [Airline_id], [Number_of_Seats], [ModelNumber]) VALUES (N'Indi1550', N'MD183', 450, N'A319')
GO
INSERT [dbo].[AIRPLANE_T] ([Airplane_id], [Airline_id], [Number_of_Seats], [ModelNumber]) VALUES (N'QAT1297', N'MD190', 200, N'737')
GO
INSERT [dbo].[AIRPLANE_T] ([Airplane_id], [Airline_id], [Number_of_Seats], [ModelNumber]) VALUES (N'QAT1524', N'MD188', 830, N'707')
GO
INSERT [dbo].[AIRPLANE_T] ([Airplane_id], [Airline_id], [Number_of_Seats], [ModelNumber]) VALUES (N'QAT7648', N'MD186', 787, N'707')
GO
insert into Airplane_T values ('AIR1511','MD180',430,747)
insert into Airplane_T values ('QAT7621','MD181',431,748)
insert into Airplane_T values ('QAT1588','MD182',432,749)
insert into Airplane_T values ('QAT1252','MD183',433,750)
insert into Airplane_T values ('Indi1511','MD185',434,751)
insert into Airplane_T values ('AMR3511','MD187',436,753)
insert into Airplane_T values ('AMR2311','MD188',437,754)
insert into Airplane_T values ('AIR3711','MD189',438,755)
insert into Airplane_T values ('AIR2811','MD191',439,756)
insert into Airplane_T values ('AIR6765','MD180',440,757)
insert into Airplane_T values ('AIR2139','MD181',441,758)
insert into Airplane_T values ('QAT8766','MD182',442,759)
insert into Airplane_T values ('INDI763','MD187',443,760)
insert into Airplane_T values ('INDI6543','MD189',444,761)
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	DCA	', N'	 Ronald-Reagan-National	', N'	 Arlington	', N'	 VA	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	DEN	', N'	 Denver-Interational	', N'	 Denver	', N'	 CO	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	DFW	', N'	 Dallas-Fort-Worth	', N'	 DFW	', N'	 TX	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	EWR	', N'	 Newark-International	', N'	 Newark	', N'	 NJ	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	FAT	', N'	 Fresno-Yosemite', N'	 Fresno	', N'	 CA	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	HNL	', N'	 Honolulu-International	', N'	 Honolulu	', N'	 HI	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	IAD	', N'	 Washington-Dulles	', N'	 Dulles	', N'	 VA	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	IAH	', N'	 Bush-Intercontinental	', N'	 Houston	', N'	 TX	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	IWA	', N'	 Phoenix-Mesa-Gateway	', N'	 Phoenix	', N'	 AZ	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	JFK	', N'	 JFK-International	', N'	 New-York	', N'	 NY	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	LAS	', N'	 McCarren-International	', N'	 Las-Vegas	', N'	 NV	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	LAX	', N'	 Los-Angeles-International	', N'	 Los-Angeles	', N'	 CA	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	MDW	', N'	 Midway	', N'	 Chicago	', N'	 IL	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	MSN	', N'	 Dane-County-Regional	', N'	 Madison	', N'	 WI	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	MSP	', N'	 Minneapolis-St-Paul	', N'	 Minneapolis-St-Paul	', N'	 MN	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	MSY	', N'	 Louis-Armstrong	', N'	 New-Orleans	', N'	 LA	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	OAK	', N'	 Oakland-International	', N'	 Oakland	', N'	 CA	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	ONT	', N'	 Ontario-International	', N'	 Ontario	', N'	 CA	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	ORD	', N'	 Chicago-OHare-International	', N'	 Chicago	', N'	 IL	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	PHX	', N'	 Phoenix-Sky-Harbor	', N'	 Phoenix	', N'	 AZ	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	SAN	', N'	 San-Diego-International	', N'	 San-Diego	', N'	 CA	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	SCK	', N'	 Stockton-Metropolitan	', N'	 Stockton	', N'	 CA	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	SFO	', N'	 San-Francisco-International	', N'	 San-Francisco	', N'	 CA	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	SJC	', N'	 San-Jose-International	', N'	 San-Jose	', N'	 CA	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	SLC	', N'	 Salt-Lake-City	', N'	 Salt-Lake-City	', N'	 UT	', N'	YES	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'	SMF	', N'	 Sacramento-International	', N'	 Sacramento	', N'	 CA	', N'	NO	')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'BOS', N' San-Francisco-International ', N' San-Francisco ', N' CA ', N' YES ')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'FAT', N'Fresno-Yosemite-International ', N' Fresno ', N' CA ', N' YES ')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'HNL', N' Honolulu-International ', N' Honolulu ', N' HI ', N' YES ')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'JFK', N' John-F-Kennedy-International ', N' New-York ', N' NY ', N' NO ')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'LAS', N' McCarren-International ', N' Las-Vegas ', N' NV ', N' NO ')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'MDW', N' Midway ', N' Chicago ', N' IL ', N' NO ')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'MSY', N' Louis-Armstrong ', N' New-Orleans ', N' LA ', N' YES ')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'OAK', N' Oakland-International ', N' Oakland ', N' CA ', N' YES ')
GO
INSERT [dbo].[AIRPORT_T] ([Airport_Code], [Airport_Name], [city], [State], [Airport_Compliance]) VALUES (N'ORD', N' Chicago-OHare-International ', N' Chicago ', N' IL ', N' NO ')
GO


INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3746, CAST(800.00 AS Decimal(10, 2)), CAST(25.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (1357, CAST(1200.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2457, CAST(2100.00 AS Decimal(10, 2)), CAST(57.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2458, CAST(2400.00 AS Decimal(10, 2)), CAST(64.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2467, CAST(280.00 AS Decimal(10, 2)), CAST(18.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (5677, CAST(175.00 AS Decimal(10, 2)), CAST(9.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (7623, CAST(1200.00 AS Decimal(10, 2)), CAST(21.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2470, CAST(3500.00 AS Decimal(10, 2)), CAST(84.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2465, CAST(3200.00 AS Decimal(10, 2)), CAST(72.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2466, CAST(2800.00 AS Decimal(10, 2)), CAST(64.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2468, CAST(2800.00 AS Decimal(10, 2)), CAST(82.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8760, CAST(2800.00 AS Decimal(10, 2)), CAST(82.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2546, CAST(1720.00 AS Decimal(10, 2)), CAST(58.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2548, CAST(1900.00 AS Decimal(10, 2)), CAST(71.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2549, CAST(723.00 AS Decimal(10, 2)), CAST(57.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2567, CAST(890.00 AS Decimal(10, 2)), CAST(41.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (2577, CAST(834.00 AS Decimal(10, 2)), CAST(19.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3257, CAST(1200.00 AS Decimal(10, 2)), CAST(57.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3468, CAST(873.00 AS Decimal(10, 2)), CAST(90.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3469, CAST(320.00 AS Decimal(10, 2)), CAST(51.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3567, CAST(834.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3577, CAST(1200.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3579, CAST(1900.00 AS Decimal(10, 2)), CAST(49.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3580, CAST(873.00 AS Decimal(10, 2)), CAST(32.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3748, CAST(573.00 AS Decimal(10, 2)), CAST(41.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3749, CAST(217.00 AS Decimal(10, 2)), CAST(52.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3750, CAST(317.00 AS Decimal(10, 2)), CAST(55.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (3751, CAST(834.00 AS Decimal(10, 2)), CAST(32.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (4396, CAST(1200.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (4397, CAST(1900.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (4555, CAST(873.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (4556, CAST(573.00 AS Decimal(10, 2)), CAST(32.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (5474, CAST(573.00 AS Decimal(10, 2)), CAST(32.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (5475, CAST(834.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (5746, CAST(1200.00 AS Decimal(10, 2)), CAST(51.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (5747, CAST(1900.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (5800, CAST(873.00 AS Decimal(10, 2)), CAST(22.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (5801, CAST(1200.00 AS Decimal(10, 2)), CAST(31.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (7443, CAST(834.00 AS Decimal(10, 2)), CAST(27.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (7444, CAST(800.00 AS Decimal(10, 2)), CAST(25.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (7432, CAST(1200.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (7533, CAST(2100.00 AS Decimal(10, 2)), CAST(57.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (7534, CAST(2400.00 AS Decimal(10, 2)), CAST(64.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (7540, CAST(280.00 AS Decimal(10, 2)), CAST(18.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (7541, CAST(175.00 AS Decimal(10, 2)), CAST(9.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (7888, CAST(1200.00 AS Decimal(10, 2)), CAST(21.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (7889, CAST(3500.00 AS Decimal(10, 2)), CAST(84.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8352, CAST(3200.00 AS Decimal(10, 2)), CAST(72.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8458, CAST(2800.00 AS Decimal(10, 2)), CAST(64.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8459, CAST(2800.00 AS Decimal(10, 2)), CAST(82.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8467, CAST(2800.00 AS Decimal(10, 2)), CAST(82.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8533, CAST(1720.00 AS Decimal(10, 2)), CAST(58.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8534, CAST(1900.00 AS Decimal(10, 2)), CAST(71.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8642, CAST(723.00 AS Decimal(10, 2)), CAST(57.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8889, CAST(573.00 AS Decimal(10, 2)), CAST(32.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8890, CAST(573.00 AS Decimal(10, 2)), CAST(32.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8910, CAST(834.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (8911, CAST(1200.00 AS Decimal(10, 2)), CAST(51.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (9092, CAST(1900.00 AS Decimal(10, 2)), CAST(42.00 AS Decimal(10, 2)))
GO                                                          
INSERT [dbo].[Cost_T] ([Flight_No], [Price], [Tax]) VALUES (9093, CAST(873.00 AS Decimal(10, 2)), CAST(22.00 AS Decimal(10, 2)))
GO
INSERT [dbo].[FLIGHT_STATUS_T] ([Flight_Number], [Status], [Actual_departure_time], [Actual_arrival_time]) VALUES (2547, N'Schedule', CAST(N'2022-01-22T12:45:00.000' AS DateTime), NULL)
GO
INSERT [dbo].[FLIGHT_STATUS_T] ([Flight_Number], [Status], [Actual_departure_time], [Actual_arrival_time]) VALUES (2577, N'On Time', CAST(N'2022-01-24T12:45:00.000' AS DateTime), NULL)
GO
INSERT [dbo].[FLIGHT_STATUS_T] ([Flight_Number], [Status], [Actual_departure_time], [Actual_arrival_time]) VALUES (3257, N'On Time', CAST(N'2022-01-30T12:45:00.000' AS DateTime), NULL)
GO
INSERT [dbo].[FLIGHT_STATUS_T] ([Flight_Number], [Status], [Actual_departure_time], [Actual_arrival_time]) VALUES (3578, N'Schedule', CAST(N'2022-01-29T12:45:00.000' AS DateTime), NULL)
GO
INSERT [dbo].[FLIGHT_STATUS_T] ([Flight_Number], [Status], [Actual_departure_time], [Actual_arrival_time]) VALUES (3745, N'Arrived', CAST(N'2022-01-23T12:45:00.000' AS DateTime), CAST(N'2022-01-24T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FLIGHT_STATUS_T] ([Flight_Number], [Status], [Actual_departure_time], [Actual_arrival_time]) VALUES (5733, N'Departed', CAST(N'2022-01-29T12:45:00.000' AS DateTime), NULL)
GO
INSERT [dbo].[FLIGHT_STATUS_T] ([Flight_Number], [Status], [Actual_departure_time], [Actual_arrival_time]) VALUES (5785, N'Delayed', CAST(N'2022-01-28T12:45:00.000' AS DateTime), CAST(N'2022-01-29T03:15:00.000' AS DateTime))
GO
INSERT [dbo].[FLIGHT_STATUS_T] ([Flight_Number], [Status], [Actual_departure_time], [Actual_arrival_time]) VALUES (7883, N'Delayed', CAST(N'2022-01-30T12:45:00.000' AS DateTime), CAST(N'2022-01-31T02:15:00.000' AS DateTime))
GO
INSERT [dbo].[FLIGHT_STATUS_T] ([Flight_Number], [Status], [Actual_departure_time], [Actual_arrival_time]) VALUES (8642, N'Arrived', CAST(N'2022-01-30T12:45:00.000' AS DateTime), CAST(N'2022-01-31T01:15:00.000' AS DateTime))
GO
INSERT [dbo].[FLIGHT_STATUS_T] ([Flight_Number], [Status], [Actual_departure_time], [Actual_arrival_time]) VALUES (8888, N'Departed', CAST(N'2022-01-27T12:45:00.000' AS DateTime), NULL)
GO






